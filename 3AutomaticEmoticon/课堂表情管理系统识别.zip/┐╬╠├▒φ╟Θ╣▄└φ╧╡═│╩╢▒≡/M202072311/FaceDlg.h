﻿#pragma once
#include<opencv2/core/core.hpp>
#include<opencv2/opencv.hpp>
using namespace cv;

// FaceRecognizeDlg 对话框
class FaceRecognizeDlg : public CDialogEx
{
// 构造
public:
	FaceRecognizeDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_M202072311_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	int Mat2CImage(Mat* mat, CImage& img);
	Mat FaceDecetion(Mat &frame);
	int function;
	CascadeClassifier cascade;
	afx_msg void OnBnClickedButtonStart();
	afx_msg void OnBnClickedButtonPause();
	afx_msg void OnBnClickedButtonOriginal();
	afx_msg void OnBnClickedButtonGray();
	afx_msg void OnBnClickedButtonMirror();
	afx_msg void OnBnClickedButtonFacedec();
};
