#include"similar.h"
#include<iostream>
using namespace std;

HashTable::HashTable() {
    for (int i = 0; i < HASHSIZE; ++i)
    {
        node[i] = NULL;
    }
}

HashTable::~HashTable() {
    cout << endl << endl << endl << endl << endl << endl;
    cout << "\t\t\t\t\t\tbye world"<<endl<<endl;
}

int HashTable::hash(const char* key) {

    return (uint)((*key) % Size);
}
//���ع�ϣֵ

Node* HashTable::lookup(const char* ch) {
    Node* np;
    uint index;
    index = hash(ch);
    for (np = node[index]; np; np = np->next) {
        if (!strcmp(ch, np->key))
        {
            return np;
        }
    }
    return NULL;
}//��������

bool HashTable::install(const char* key, const int* value) {
    uint index;
    Node* np;
    if (!(np = lookup(key))) {
        index = hash(key);
        np = (Node*)malloc(sizeof(Node));
        if (!np) return false;
        np->key = key;
        np->next = node[index];
        node[index] = np;
    }
    np->value = value;
    return true;
}

void HashTable::display() {
    Node* temp;
    for (int i = 0; i < HASHSIZE; ++i)
    {
        if (!node[i]) {
            printf("%d\n", i);
        }
        else
        {
            printf("");
            for (temp = node[i]; temp; temp = temp->next)
            {
                cout << i << setw(50) << temp->key << endl;
            }
        }
    }
}