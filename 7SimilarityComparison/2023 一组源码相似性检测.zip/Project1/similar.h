#ifndef _SIMILAR_H_
#define _SIMILAR_H_

#include<iostream>
#include<cstring>
#include<fstream>
#include<math.h>
#include<iomanip>
#include<string>

#define N 50000
#define HASHSIZE 97
#define  Size    97


typedef unsigned int uint;

typedef struct Node {
    const char* key;
    const int* value;
    Node* next;
}Node;//ָ�����鶨��

class HashTable {
private:
    Node* node[HASHSIZE];
public:

    HashTable();
    ~HashTable();
    int hash(const char* key);
    Node* lookup(const char* key);
    bool install(const char* key, const int* value);
    void display();
};//�ļ�������ϣֵ��ȡ


#endif // !_SIMILAR_H_
