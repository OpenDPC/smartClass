#include"similar.h"
#include<iostream>
using namespace std;

extern int hash1[HASHSIZE+10], hash2[HASHSIZE+10];
extern HashTable* ht;

static void judege_c(int hash[], const char* ch) {
    Node* np;
    int x;
    x = ht->hash(ch);
    if (x >= 0 && x <= HASHSIZE)
    {
        np = ht->lookup(ch);
        if (np != NULL)
            if (!strcmp(ch, np->key))
            {
                hash[*(np->value)]++;
            }
    }
}

static int deal_data1(char data[]) {
    char ch;
    char filename[2000];
    cout << "�������һ���ļ���ַ��" << endl;
    cin >> filename;
    ifstream infile(filename, ios::in);
    if (!infile) {
        cout << "�򿪵�һ���ļ�����" << endl;
        exit(0);
    }
    ofstream outfile("dealt_data1.txt", ios::out);
    if (!outfile) {
        cout << "Open dealt_data1 error!" << endl;
        exit(0);
    }

    while (infile.get(ch)) {
        if (ch == '(' || ch == ')' || ch == '{' || ch == '}' || ch == '[' || ch == ']' || ch == ',' || ch == '<' || ch == '>' || ch == ';')
            ch = ' ';
        outfile.put(ch);
    }
    infile.close();
    outfile.close();
    ifstream infile1("dealt_data1.txt", ios::in);
    if (!infile1) {
        cout << "open dealt_data1 error!" << endl;
    }
    int cnt = 0;
    while (infile1.get(ch)) {
        data[cnt++] = ch;
    }
    infile1.close();
    return cnt;
}

static int deal_data2(char data[]) {
    char ch;
    char filename[200];
    cout << "������ڶ����ļ���ַ��" << endl;
    cin >> filename;
    ifstream infile(filename, ios::in);
    if (!infile) {
        cout << "�򿪵ڶ����ļ�����" << endl;
        exit(0);
    }
    ofstream outfile("dealt_data2.txt", ios::out);
    if (!outfile) {
        cout << "Open dealt_data2 error!" << endl;
        exit(0);
    }
    while (infile.get(ch)) {
        if (ch == '(' || ch == ')' || ch == '{' || ch == '}' || ch == '[' || ch == ']' || ch == ',' || ch == '<' || ch == '>' || ch == ';')
            ch = ' ';
        outfile.put(ch);
    }
    infile.close();
    outfile.close();
    ifstream infile2("dealt_data2.txt", ios::in);
    if (!infile2) {
        cout << "open dealt_data2 error!" << endl;
    }
    int cnt = 0;
    while (infile2.get(ch)) {
        data[cnt] = ch;
        cnt++;
    }
    infile2.close();
    return cnt;
}

static void calcunum_c(const char data[], const int n, const int num) {
    char ch[200];
    int i, j,x;
    for (i = 0; i < n; i++) {
        if (data[i] != ' ' && data[i] != '\n' && data[i] != '\t') {
            j = 0;
            x = i;
            while (data[x] != ' ' && data[x] != '\n' && data[x] != '\t') {
                ch[j] = data[x];
                x++;
                j++;
                if (x == n)
                {
                    break;
                }
            }
            ch[j] = '\0';

            if (num == 1)
            {
                judege_c(hash1, ch);
            }
            else if(num == 2)
            {
                judege_c(hash2, ch);
            }
            else
            {
                cout << "calcunum_c����ʹ�ô���" << endl;
                exit(0);
            }
        }
    }
}

static double possibility(int hash1[], int hash2[])
{
    int i;
    double sum = 0, pos=-1;
    for (i = 0; i < Size; i++)
    {
        sum = sum + hash1[i] * hash2[i];
    }
    double sum1 = 0;
    for (i = 0; i < Size; i++)
    {
        sum1 = sum1 + hash1[i] * hash1[i];
    }
    double sum2 = 0;
    for (i = 0; i < Size; i++)
    {
        sum2 = sum2 + hash2[i] * hash2[i];
    }
    double product = sqrt(sum1) * sqrt(sum2);
    pos = (sum/product) * 100;
    return pos;
}

static double possibility1(int hash1[], int hash2[])
{
    int i;
    double sum = 0, pos1;
    for (i = 0; i < Size; i++)
    {
        sum = sum + (hash1[i] - hash2[i]) * (hash1[i] - hash2[i]);
    }
    pos1 = sqrt(sum);
    return pos1;
}