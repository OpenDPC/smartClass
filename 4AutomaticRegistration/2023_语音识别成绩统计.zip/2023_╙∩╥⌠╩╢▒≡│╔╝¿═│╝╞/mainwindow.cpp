#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "sqlwindow1.h"
#include <QTableWidget>
#include "src/sqlmain.h"

int speechmain();
extern int STATUS;
extern MYSQL* con;

mainwindow::mainwindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::mainwindow)
{

    ui->setupUi(this);
    setWindowTitle("语音成绩管理系统");
}

mainwindow::~mainwindow()
{

    delete ui;
}


void mainwindow::on_pushButton_2_clicked()
{
    sqlwindow1 *sw = new sqlwindow1(this);
    connect(sw,SIGNAL(WindowClosed()),this,SLOT(mainwindowshow()));
    sw->show();//显示子窗口
    this -> hide();//隐藏主窗口
}

void mainwindow::mainwindowshow(){
    mainwindow *sw = new mainwindow(this);
    sw->show();//显示主窗口
}

void mainwindow::on_pushButton_clicked()
{
//    int a;
    //成功样式
//    QMessageBox::information(this,"information","录音成功\n结果为：",QMessageBox::NoButton,QMessageBox::Close);

//    if (a==16384) //yes返回16384，no返回65536
//    {
//    QMessageBox::information(this,"information","录音成功\n结果为：",QMessageBox::NoButton,QMessageBox::Close);
//    }
//    else //(a==65536)
//    {
//    return;
//    }
    //这里可以写录音接口
        STATUS = 0;
    speechmain();
        //上面这句要写在main函数结束之前
        if(STATUS)
            QMessageBox::warning(this,"warning","录音失败，请重试");
}

