#include "sqlwindow1.h"
#include "ui_sqlwindow1.h"
#include "mainwindow.h"
#include "src/sqlmain.h"
#include <QDebug>

extern char cur_key;
extern int STATUS;
extern MYSQL* con;


sqlwindow1::sqlwindow1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::sqlwindow1),
    tableWidget(NULL),
    centralWidget(NULL),
    TableData(NULL),
    TableDataCount(0),
    Vlayout(NULL),
    comboBox(NULL),
    Hlayout(NULL),
    Getname(NULL),
    VectifyButton(NULL),
    num(0)
{
    ui->setupUi(this);
    setWindowTitle("成绩表格");
    // 创建表格控件
    tableWidget = new QTableWidget(this);
    tableWidget->setColumnCount(3); // 设置列数
    tableWidget->setHorizontalHeaderLabels({"组号", "姓名", "成绩"}); // 设置表头
    // 设置表格属性
    tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers); // 禁止编辑
    tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows); // 选择整行
    tableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff); // 禁止水平滚动条
    tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

    centralWidget = new QWidget(this);

    Vlayout = new QVBoxLayout(this);

    Hlayout = new QHBoxLayout(this);

    comboBox = new QComboBox(this);

   Getname = new QLineEdit(this);
   VectifyButton = new QPushButton("搜索",this);


    //    // 添加选项到ComboBox
    comboBox->addItem("默认排序");
    comboBox->addItem("成绩排序");
    comboBox->addItem("姓名搜索");
    comboBox->setCurrentIndex(0);

    connect(VectifyButton, SIGNAL(clicked()), this, SLOT(SearchbyName()));

    ViewModeSwitch();
    connect(comboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(ViewModeSwitch()));
}

void sqlwindow1::ViewModeSwitch()
{
    MYSQL_RES *result = NULL;
    MYSQL_ROW row;

    QLayoutItem* item;

        if (mysql_query(con, "SELECT COUNT(*) FROM cppstudentscore"))
        {
            STATUS = -1; // 执行失败，将全局变量 STATUS 设为 -1
            return;
        }
        result = mysql_store_result(con);
        if (result != nullptr)
        {
            MYSQL_ROW row = mysql_fetch_row(result);
            if (row != nullptr)
            {
                num = atoi(row[0]);
            }
            else
            {
                STATUS = -1; // 执行失败，将全局变量 STATUS 设为 -1
                return;
            }
        }
        else
        {
            STATUS = -1; // 执行失败，将全局变量 STATUS 设为 -1
            return;
        }
        mysql_free_result(result);
        result = NULL;
        Getname->hide();
        VectifyButton->hide();
        while ((item = Hlayout->takeAt(0)) != nullptr);
        while ((item = Vlayout->takeAt(0)) != nullptr);
    switch(comboBox->currentIndex())
    {
    case 0:
        SortbyDefault();
        break;
    case 1:
        SortbyScore();
        break;
    case 2:
        SortbySearch();
        break;
    }
}

void sqlwindow1::SearchbyName()
{
        if(TableData!=NULL)
        {
            for (int i = 0; i < TableDataCount; ++i)
            {
                    delete TableData[i].group;
                    delete TableData[i].name;
                    delete TableData[i].score;
            }
            delete[] TableData;
            TableData = NULL;
        }



        QString searchName = Getname->text();  // 获取输入框中的字符串

        // 构建查询语句
        char query[256];
        memset(query,0,256);
        sprintf(query, "SELECT * FROM cppstudentscore WHERE name LIKE '%s%%'", searchName.toLocal8Bit().data());
//        memcpy(query,"SELECT * FROM cppstudentscore WHERE name LIKE '杨%'",sizeof(query));

        // 执行查询语句
        if (mysql_query(con, query) == 0)
        {
            // 获取查询结果
            MYSQL_RES* result = mysql_store_result(con);
            if (result != NULL)
            {
                    // 获取列数
                    num  = mysql_num_rows(result);
                        tableWidget->setRowCount(num); // 设置行数
                        TableData = new tablerow[num];
                        TableDataCount = num;

                        // 遍历结果集
                    MYSQL_ROW row;
                    student temp;
                        for(int j = 0;j<num;++j)
                        {
                            row = mysql_fetch_row(result);
                            strncpy(temp.name, row[1], sizeof(temp.name));
                            temp.group = atoi(row[0]);
                            temp.score = atoi(row[2]);
                            TableData[j].group = new QTableWidgetItem(QString::number(temp.group));
                            TableData[j].name = new QTableWidgetItem(QString::fromLocal8Bit(temp.name));
                            TableData[j].score = new QTableWidgetItem(QString::number(temp.score));
                            tableWidget->setItem(j, 0, TableData[j].group);
                            tableWidget->setItem(j, 1, TableData[j].name);
                            tableWidget->setItem(j, 2, TableData[j].score );
                        }

                    // 释放结果集
                    mysql_free_result(result);
            }
        }
        else
        {
            // 查询失败
            fprintf(stderr,mysql_error((con)));
            STATUS = -1;
            return;
        }


}

void sqlwindow1::SortbySearch()
{
    MYSQL_RES *result = NULL;
    MYSQL_ROW row;
    student temp;

    Hlayout->addWidget(comboBox,5);
    Hlayout->addWidget(Getname,3);
    Hlayout->addWidget(VectifyButton,2);
    Hlayout->setContentsMargins(0, 5, 0, 5); // 设置上下边距为 10 像素
    Getname->show();
    VectifyButton->show();

    Vlayout->addLayout(Hlayout);
    Vlayout->addWidget(tableWidget);
    centralWidget->setLayout(Vlayout);
    setCentralWidget(centralWidget);

}

void sqlwindow1::SortbyScore()
{
    MYSQL_RES *result = NULL;
    MYSQL_ROW row;
    student temp;

    if(TableData!=NULL)
    {
        for (int i = 0; i < TableDataCount; ++i)
        {
            delete TableData[i].group;
            delete TableData[i].name;
            delete TableData[i].score;
        }
        delete[] TableData;
        TableData = NULL;
    }

    tableWidget->setRowCount(num); // 设置行数
    TableData = new tablerow[num];
    TableDataCount = num;


    if (mysql_query(con, "SELECT * FROM cppstudentscore order by score desc"))
    {
        STATUS = -1; // 执行失败，将全局变量 STATUS 设为 -1
        return;
    }


    result = mysql_store_result(con);
    if (result == NULL)
    {
        STATUS = -1; // 获取结果集失败，将全局变量 STATUS 设为 -1
        return;
    }


    for(int j = 0;j<num;++j)
    {
        row = mysql_fetch_row(result);
        strncpy(temp.name, row[1], sizeof(temp.name));
        temp.group = atoi(row[0]);
        temp.score = atoi(row[2]);
        TableData[j].group = new QTableWidgetItem(QString::number(temp.group));
        TableData[j].name = new QTableWidgetItem(QString::fromLocal8Bit(temp.name));
        TableData[j].score = new QTableWidgetItem(QString::number(temp.score));
        tableWidget->setItem(j, 0, TableData[j].group);
        tableWidget->setItem(j, 1, TableData[j].name);
        tableWidget->setItem(j, 2, TableData[j].score );
    }

    mysql_free_result(result);


    Vlayout->addWidget(comboBox);
    Vlayout->addWidget(tableWidget);
    centralWidget->setLayout(Vlayout);
    setCentralWidget(centralWidget);
}

void sqlwindow1::SortbyDefault()
{
    MYSQL_RES *result = NULL;
    MYSQL_ROW row;
    student temp;

    if(TableData!=NULL)
    {
        for (int i = 0; i < TableDataCount; ++i)
        {
            delete TableData[i].group;
            delete TableData[i].name;
            delete TableData[i].score;
        }
            delete[] TableData;
        TableData = NULL;
    }

        tableWidget->setRowCount(num); // 设置行数
        TableData = new tablerow[num];
        TableDataCount = num;


        if (mysql_query(con, "SELECT * FROM cppstudentscore"))
        {
            STATUS = -1; // 执行失败，将全局变量 STATUS 设为 -1
            return;
        }


        result = mysql_store_result(con);
        if (result == NULL)
        {
            STATUS = -1; // 获取结果集失败，将全局变量 STATUS 设为 -1
            return;
        }


        for(int j = 0;j<num;++j)
        {
            row = mysql_fetch_row(result);
            strncpy(temp.name, row[1], sizeof(temp.name));
            temp.group = atoi(row[0]);
            temp.score = atoi(row[2]);
            TableData[j].group = new QTableWidgetItem(QString::number(temp.group));
            TableData[j].name = new QTableWidgetItem(QString::fromLocal8Bit(temp.name));
            TableData[j].score = new QTableWidgetItem(QString::number(temp.score));
            tableWidget->setItem(j, 0, TableData[j].group);
            tableWidget->setItem(j, 1, TableData[j].name);
            tableWidget->setItem(j, 2, TableData[j].score );
        }

        mysql_free_result(result);

    Vlayout->addWidget(comboBox);
    Vlayout->addWidget(tableWidget);
    centralWidget->setLayout(Vlayout);
    setCentralWidget(centralWidget);
//    setCentralWidget(tableWidget);
}

sqlwindow1::~sqlwindow1()
{
    for (int i = 0; i < TableDataCount; ++i)
    {
        delete TableData[i].group;
        delete TableData[i].name;
        delete TableData[i].score;
    }
    if (TableData != NULL)
    {
        delete[] TableData;
        TableData = NULL;
    }

    if (tableWidget != NULL)
    {
        delete tableWidget;
        tableWidget = NULL;
    }

    if (centralWidget != NULL)
    {
        delete centralWidget;
        centralWidget = NULL;
    }

    if (Vlayout != NULL)
    {
        delete Vlayout;
        Vlayout = NULL;
    }

    if (Hlayout != NULL)
    {
        delete Hlayout;
        Hlayout = NULL;
    }

    if (comboBox != NULL)
    {
        delete comboBox;
        comboBox = NULL;
    }
    if (Getname != NULL)
    {
        delete Getname;
        Getname = NULL;
    }
    if (VectifyButton != NULL)
    {
        delete VectifyButton;
        VectifyButton = NULL;
    }

    delete ui;

}
void sqlwindow1::closeEvent(QCloseEvent* event)
{
    emit windowClosed();
    mainwindow *sw = new mainwindow(this);
    sw->show();//关闭子窗口时显示主窗口
}


