#ifndef SQLWINDOW1_H
#define SQLWINDOW1_H

#include <QMainWindow>
#include <QEvent>
#include <QTableWidget>
#include <QVBoxLayout>
#include <QHeaderView>
#include <QComboBox>
#include <QPushButton>
#include <QWidget>
#include <QObject>
#include <QLineEdit>
#include <fstream>

struct tablerow{
    QTableWidgetItem *group;
    QTableWidgetItem *name;
    QTableWidgetItem *score;
};

namespace Ui {
class sqlwindow1;
}

class sqlwindow1 : public QMainWindow
{
    Q_OBJECT

public:
    explicit sqlwindow1(QWidget *parent = nullptr);
    ~sqlwindow1();
private:
    Ui::sqlwindow1 *ui;
    QTableWidget * tableWidget;
    QWidget *centralWidget;
    tablerow* TableData;
    int TableDataCount;
    QVBoxLayout *Vlayout;
        QComboBox* comboBox;
    QHBoxLayout* Hlayout;
        QLineEdit* Getname;
    QPushButton* VectifyButton;
    int num;
     void SortbyDefault();
    void SortbySearch();
     void SortbyScore();
protected:
    void closeEvent(QCloseEvent* event);
signals:
    void windowClosed();
private slots:
    void ViewModeSwitch();
    void SearchbyName();
};

#endif // SQLWINDOW1_H

