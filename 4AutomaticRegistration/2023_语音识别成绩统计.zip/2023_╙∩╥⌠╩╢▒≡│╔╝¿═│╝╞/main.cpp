#include "mainwindow.h"
#include <QApplication>
#include "src/sqlmain.h"

mainwindow* mainwindow_pt = NULL;
char cur_key = 0;
int STATUS = 0;
extern int upload_on;
extern MYSQL* con;

int main(int argc, char *argv[])
{
    setbuf(stderr, NULL);
    upload_on = 1;
    if (sqlmain_init() == -1)
        return -1;
    QApplication a(argc, argv);
    mainwindow w;
    mainwindow_pt = &w;
    w.show();
    int exitCode = a.exec();
    mysql_close(con);
     return exitCode;
}
